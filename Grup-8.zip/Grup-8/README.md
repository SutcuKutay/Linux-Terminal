# isletim-sistemleri-projesi
Bu, Sakarya Üniversitesi Bilgisayar Mühendisliği İşletim Sistemleri dersinin projesidir.

Emeği Geçenler:

	Kutay Sütçü
	
	Hana Kajan
	
	İrem Nur Ustabaş
	
	Burak Berslan
	
	Şeyma Ertuğrul
	
	
Dosyaların açıklamaları:

	main.c ===> Bu dosya kodların yazılı olduğu kaynak dosyasıdır.
	
	makefile ===> Bu dosya makefile'dir.
	
	README.md ===> Bu ReadMe dosyasında proje hakkında bilgilendirmeler yapılır.
	
	uyg ===> Bu çalıştırılabilir programdır.
	
	
Derleme:

	main.c'nin bulunduğu konumda terminal açılır. "make compile" yazılır.
	
	
Çalıştırma:

	main.c'nin bulunduğu konumda terminal açılır. Projeyi çalıştırmak için terminale sadece "make" yazmak yeterlidir.
	

Karşılaşılan zorluklar:

	Doğruyu söylemek gerekirse her adımda zorlandık. Ama birlikte el ele verip bu zorlukların üstesinden geldik.
	
	
Yardımcı Kaynaklar:

	-Ders dokümanları
	
	-https://web.stanford.edu/class/cs110/lectures
